.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Testing the equality of a high dimensional set of densities")
}


# Opciones
#===================
.onLoad <- function(libname, pkgname) {

  requireNamespace("npcp", quietly = TRUE)
}
